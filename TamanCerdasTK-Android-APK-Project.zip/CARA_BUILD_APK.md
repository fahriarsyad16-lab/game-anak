# Panduan Membuat File APK Android (Taman Bermain Cerdas TK)

Paket ini telah mengonversi file HTML **Taman Bermain Cerdas TK** menjadi proyek **Android Native WebView** lengkap dengan dukungan **Suara Bahasa Indonesia (Android Native TextToSpeech)** dan **Web Audio Synthesizer**.

---

## Cara 1: Langsung Pasang di HP Android Tanpa Coding (Paling Mudah - 10 Detik)
Aplikasi ini sudah mendukung standar **Progressive Web App (PWA) / WebAPK Android**:
1. Buka link aplikasi ini di **Google Chrome** pada HP Android Anda.
2. Ketuk tombol **"Pasang Aplikasi di HP"** di bagian atas aplikasi, atau ketuk menu titik tiga (⋮) di pojok kanan atas Chrome lalu pilih **"Instal aplikasi"** / **"Tambahkan ke layar utama"**.
3. Chrome akan otomatis membungkus aplikasi menjadi **WebAPK** yang muncul di daftar aplikasi Android Anda dan bisa dimainkan **Full-Screen & Offline**!

---

## Cara 2: Export File `.apk` Gratis Tanpa Install Aplikasi via PWABuilder
1. Buka situs [https://www.pwabuilder.com](https://www.pwabuilder.com)
2. Masukkan URL aplikasi ini: `https://ais-dev-kb7cpypcn7ci3ob5ksoqk4-459956401016.asia-southeast1.run.app`
3. Klik **Start** -> Pilih **Package for Stores** -> Klik **Generate Package** pada bagian **Android**.
4. File **`.apk`** siap diunduh dan langsung dikirim ke WhatsApp atau dipasang di HP Android!

---

## Cara 3: Build File `.apk` Menggunakan Android Studio / GitHub Actions (Dari File ZIP Ini)
Proyek di dalam folder ini sudah siap dikompilasi menjadi file `.apk`:
- **Menggunakan Android Studio**:
  1. Ekstrak file ZIP ini ke folder komputer Anda.
  2. Buka **Android Studio** -> **Open** -> Pilih folder hasil ekstrak.
  3. Klik menu **Build** -> **Build Bundle(s) / APK(s)** -> **Build APK(s)**.
  4. File APK tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

- **Tanpa Android Studio (Otomatis di Cloud via GitHub)**:
  1. Upload seluruh isi folder ini ke repositori GitHub Anda.
  2. Buka tab **Actions** di GitHub, workflow `Build Android APK` akan otomatis berjalan dan menghasilkan file `app-debug.apk` yang siap Anda unduh!
